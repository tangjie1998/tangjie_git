package zuoye0711;

public class personTest {
	public static void main(String[] args) {
		person a=new person("С��",20);
		a.display();
		
	}
	

}
