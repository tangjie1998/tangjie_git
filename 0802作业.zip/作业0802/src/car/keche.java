package car;

import java.util.Scanner;

 class keche extends qiche{
	  void SUM(){
		Scanner sc=new Scanner(System.in);
		System.out.println("��ѡ��Ʒ�ƣ�1.��  2.����");
		choose2=sc.nextInt();
		if(choose1==1){
				SumMoney=800;
				if (choose2==1) {
					chepai="��6566754";
				}else{
					chepai="��8696997";
				}
				
		}else{
				SumMoney=1500;	
				if (choose2==1) {
					chepai="��9696996";
				}else{
					chepai="��8696998";
				}
		}
		
		
	}
	
	void Sum() {
		if (days>=150) {
			SumMoney=SumMoney*0.6*days;
		}else if(days>=30){
			SumMoney=SumMoney*0.7*days;
		}else if(days>=7){
			SumMoney=SumMoney*0.8*days;
		}else if(days>=3){
			SumMoney=SumMoney*0.9*days;
		}else{
			SumMoney=SumMoney*days;
		}
		
	}

	
	

}
