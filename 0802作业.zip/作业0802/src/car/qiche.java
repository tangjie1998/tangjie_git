package car;

  class qiche {
  static int days;
  static double SumMoney;
  static int choose1;
  int choose2;
  static String chepai;
}
