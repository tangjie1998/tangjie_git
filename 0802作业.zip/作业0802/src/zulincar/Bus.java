package zulincar;

public class Bus extends Car {
	   private int zuowei;//��λ
		public double zujin(int days) {
			double price=this.getDaymoney()*days;
			if(days>=3&&days<7){
				price*=0.9;
			}else if(days>=7&&days<30){
				price*=0.8;
			}else if(days>=30&&days<150){
				price*=0.7;
			}else if(days>=150){
				price*=0.6;
			}
			return price;
		}
	
		public int getZuowei() {
			return zuowei;
		}

		public void setZuowei(int zuowei) {
			this.zuowei = zuowei;
		}

		public Bus(String chepai, String brand, int daymoney, int zuowei) {
			super(chepai, brand, daymoney);
			this.zuowei = zuowei;
		}
        public Bus(){
        }
		


}
