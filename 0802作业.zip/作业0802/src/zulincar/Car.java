package zulincar;
//������
public abstract class Car {
    private String chepai;//����
    private String brand;//Ʒ��
    private int daymoney;//�����
    public Car(String chepai, String brand, int daymoney) {
		super();
		this.chepai = chepai;
		this.brand = brand;
		this.daymoney = daymoney;
	}
	public Car(){
    	
    }
	public String getChepai() {
		return chepai;
	}
	public void setChepai(String chepai) {
		this.chepai = chepai;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getDaymoney() {
		return daymoney;
	}
	public void setDaymoney(int daymoney) {
		this.daymoney = daymoney;
	}
	
	public abstract double zujin(int days);
	
	
	
}
