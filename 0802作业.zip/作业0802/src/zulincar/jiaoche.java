package zulincar;

public class jiaoche extends Car {
     private String type;//�ͺ�
	public double zujin(int days) {
		double price=this.getDaymoney()*days;
		if(days>7&&days<=30){
			price*=0.9;
		}else if(days>30&&days<=150){
			price*=0.8;
		}else if(days>=150){
			price*=0.7;
		}
		return price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public jiaoche(String chepai, String brand, int daymoney, String type) {
		super(chepai, brand, daymoney);
		this.type = type;
	}
	public jiaoche(){
		
	}

}
