package S;

public class Yuan extends Tipe{
	String name="Բ";
	public double S() {
		return Tipe.L*Tipe.L/12.56;//Բ�����
	}
	public void print(){
		System.out.println("Բ");
	}

}
