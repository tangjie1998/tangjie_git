package S;

public class Test {
public static void main(String[] args) {
	Tipe tmp;
	Tipe [] A={new Sanjiaoxing(),new Yuan(),new zhengfangxing()};
	double S[]=new double[3];
	for (int i = 0; i < A.length; i++) {
		S[i]=A[i].S();
	}
	for (int i = 0; i < S.length; i++) {
		for (int j = 0; j < S.length-i-1; j++) {
			if(S[i]>S[i+1]){
				tmp=A[i];
				A[i]=A[i+1];
				A[i+1]=tmp;
			}
		}
	}
   A[A.length-1].print();
   
    
}
}
