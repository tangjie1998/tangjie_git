package S;

public class Sanjiaoxing extends Tipe{
	String name="������";
	
	public double S() {
		return Tipe.L/(int) ((2+Math.sqrt(2))*Tipe.L/(2+Math.sqrt(2))/2);
	}
	public void print(){
		System.out.println("������");
	}

}
