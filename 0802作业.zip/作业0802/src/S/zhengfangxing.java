package S;

public class zhengfangxing extends Tipe{
	
	public double S() {
		return (Tipe.L/4)*(Tipe.L/4);
	}
	public void print(){
		System.out.println("������");
	}

}
